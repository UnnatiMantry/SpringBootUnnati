package com.example.javafinalassignment;

//import com.example.javafinalassignment.EmployUtility.EmployeeUtility;
//import com.example.javafinalassignment.EmployeeDAO.EmployeeDB;
//import com.example.javafinalassignment.EmployeeDAO.OldEmployeeRecord;
//import com.example.javafinalassignment.entities.Employee;
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.util.Date;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
//@SpringBootTest
//class JavaFinalAssignmentApplicationTests {
//
//	EmployeeUtility eu = new EmployeeUtility();
//	EmployeeDB edb = new EmployeeDB();
//	OldEmployeeRecord oer = new OldEmployeeRecord();

//	@Test
//	public void genEmployeeEmailTest()   // getting email
//	{
//
//		Employee emp = new Employee("tony","stark",2016,"FTE");
//		String expected = "tony.stark@hoppipolla.com";
//		assertEquals(expected,eu.genEmployeeEmail(emp));
//
//
//	}
//
//	@Test
//	public void employeeResignationTest(){  //getting notice period date
//
//		Employee emp = new Employee("tony","stark",1221);
//		Date date = new Date("22/01/2020");
//		String actual = eu.employeeRegination(emp);
//		String expected = "21/02/2020";
//
//		assertEquals(expected,actual);
//	}
//
//	@Test
//	public void genEmployeeCodeTest(){ //generating employee code
//
//		Employee emp = new Employee("tony","stark","FTE",2018);
//		int count = 10;
//		String actual = eu.genEmployeeCode(emp);
//		String expected = "HOP-2018-FTE-10";
//
//		assertEquals(expected,actual);
//	}

//	@Test
//	public void addEmployeeTest(){ //adding an employee
//
//		Employee emp = new Employee("tony","stark",2015,"FTE");
//
//		assertTrue(edb.addEmployee(emp));
//
//	}
//
////	@Test
////	public void onboardingCountTest(){  // count no of employees onboarded on a particular date
////
////		int expected = edb.onboardingCount("01/03/2021");
////		int actual = 2;
////		assertEquals(expected,actual);
////
////
////	}
////
////	@Test
////	public void separationCountTest(){ // Count no of employees leaving the company on a particular date
////
////		int expected = oer.seperationCount("21/02/2020");
////		int actual =1;
////
////		assertEquals(expected,actual);
////	}
//
//}
